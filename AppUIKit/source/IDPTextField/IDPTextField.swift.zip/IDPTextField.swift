//
//  IDPTextField.swift
//  AppUIKit
//
//  Created by Artem Chabannyi on 3/1/19.
//  Copyright © 2019 IDAP Group. All rights reserved.
//

import UIKit

public class IDPTextField: UITextField {

    public var lineColor: UIColor = .gray
    
    public var errorLineColor: UIColor = .red
    
    public var activeLineColor: UIColor = .green
    
    public var errorText: String? = nil {
        didSet {
            self.errorLabel.text = errorText
            self.updateLineColor()
        }
    }
    
    public var errorColor: UIColor = .red {
        didSet {
            self.errorLabel.textColor = errorColor
        }
    }
    
    @objc public var padding = UIEdgeInsets()
    
    // MARK: - Private properties
    
    private var lineLayer: CALayer?
    
    private let errorLabel = UILabel()
    
    // MARK: - Initializations and Deallocations
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    private func commonInit() {
        self.addSubview(self.errorLabel)
        self.settupBottomBorder(color: self.lineColor)
    }
    
    // MARK: - Override methods
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        self.lineLayer?.frame = CGRect(x: 0, y: self.bounds.height - 1, width: self.bounds.width, height: 1)
    }
    
    override public func textRect(forBounds bounds: CGRect) -> CGRect {
        return self.internalRect(forBounds: bounds)
    }
    
    override public func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return self.internalRect(forBounds: bounds)
    }
    
    override public func editingRect(forBounds bounds: CGRect) -> CGRect {
        return self.internalRect(forBounds: bounds)
    }
    
    // MARK: - Private methods
    
    private func settupBottomBorder(color: UIColor) {
        self.borderStyle = .none
        
        let lineLayer = CALayer()
        lineLayer.backgroundColor = color.cgColor
        lineLayer.frame = CGRect(x: 0, y: self.bounds.height - 1, width: self.bounds.width, height: 1)
        self.lineLayer = lineLayer
        self.layer.addSublayer(lineLayer)
    }
    
    private func internalRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: self.internalEdgeInsets())
    }
    
    private func internalEdgeInsets() -> UIEdgeInsets {
        var padding = self.padding
        let pairs = [(self.leftView, self.leftViewMode, { (rect: CGRect) in padding.left += rect.size.width }),
                     (self.rightView, self.rightViewMode, { (rect: CGRect) in padding.right += rect.size.width })]
        pairs.forEach { (view, viewMode, operation) in
            view.map {
                if viewMode == .always || viewMode == .unlessEditing {
                    operation($0.frame)
                }
            }
        }
        return padding
    }
    
    private func updateLineColor() {
        
    }
}
